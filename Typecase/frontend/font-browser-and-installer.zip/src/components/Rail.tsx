import { useEffect, useRef, useState } from "react";
import type { Cat, Face } from "../data/catalog";
import { CATS } from "../data/catalog";
import { loadFace } from "../lib/fonts";

/** sets a row's name in its own face, loading the webfont only when it nears the viewport */
function FaceName({ face }: { face: Face }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [state, setState] = useState<"idle" | "loading" | "ok" | "error">("idle");

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (!entries.some((e) => e.isIntersecting)) return;
        io.disconnect();
        setState("loading");
        loadFace(face.n, [400, 600], !!face.i).then((r) => setState(r === "ok" ? "ok" : "error"));
      },
      { rootMargin: "300px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [face.n, face.i]);

  return (
    <span
      ref={ref}
      className="block truncate text-[25px] leading-[1.1] transition-[filter,opacity] duration-500"
      style={{
        fontFamily: `"${face.n}", "Bodoni Moda", Georgia, serif`,
        fontWeight: 400,
        filter: state === "ok" ? "blur(0)" : state === "loading" ? "blur(3px)" : "none",
        opacity: state === "error" ? 0.4 : 1,
      }}
    >
      {face.n}
    </span>
  );
}

type Props = {
  faces: Face[];
  total: number;
  selected: Face;
  onSelect: (f: Face) => void;
  query: string;
  setQuery: (q: string) => void;
  cat: Cat | "All";
  setCat: (c: Cat | "All") => void;
};

export default function Rail({ faces, total, selected, onSelect, query, setQuery, cat, setCat }: Props) {
  return (
    <div className="flex h-full flex-col">
      <div className="sticky top-0 z-10 bg-[#f2ede4] pt-5 pb-3">
        <div className="flex items-baseline justify-between border-b border-[#14110e] pb-1">
          <h2 className="lab">Index of faces</h2>
          <span className="lab num text-[#8a8072]">
            {String(faces.length).padStart(2, "0")}/{total}
          </span>
        </div>

        <label className="mt-3 block">
          <span className="sr-only">Search faces</span>
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search family, designer, use…"
            className="mono w-full border-b border-[#d8d0c2] bg-transparent pb-1.5 text-[13px] placeholder:text-[#8a8072]/70 focus:border-[#c8341e] focus:outline-none"
          />
        </label>

        <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`lab transition-colors ${
                cat === c ? "text-[#c8341e]" : "text-[#8a8072] hover:text-[#14110e]"
              }`}
            >
              {cat === c ? "▍" : ""}
              {c}
            </button>
          ))}
        </div>
      </div>

      <ul className="rail max-h-[80vh] min-h-0 flex-1 overflow-y-auto border-b border-[#d8d0c2] pb-10 lg:max-h-none lg:border-b-0">
        {faces.map((f) => {
          const on = f.n === selected.n;
          return (
            <li key={f.n} className="border-b border-[#d8d0c2]">
              <button
                onClick={() => onSelect(f)}
                aria-current={on ? "true" : undefined}
                className="group relative block w-full py-2.5 pr-2 pl-3 text-left transition-[padding] duration-200 hover:pl-5 focus-visible:pl-5 focus-visible:outline-none"
              >
                <span
                  className={`absolute top-0 bottom-0 left-0 w-[3px] bg-[#c8341e] transition-transform duration-200 ${
                    on ? "scale-y-100" : "scale-y-0 group-hover:scale-y-50"
                  }`}
                  style={{ transformOrigin: "top" }}
                />
                <FaceName face={f} />
                <span className="mt-1 flex items-baseline justify-between gap-2">
                  <span className="lab truncate text-[#8a8072] group-hover:text-[#14110e]">
                    {f.d}
                  </span>
                  <span className="lab num shrink-0 text-[#8a8072]">
                    {on ? <span className="text-[#c8341e]">SEL </span> : null}
                    {f.y}
                  </span>
                </span>
              </button>
            </li>
          );
        })}

        {faces.length === 0 && (
          <li className="px-3 py-10">
            <p className="disp text-[28px] leading-tight">Nothing in the case.</p>
            <p className="lab mt-2 text-[#8a8072]">
              No face matches “{query}” under {cat}. Clear the filter to see all {total}.
            </p>
          </li>
        )}
      </ul>
    </div>
  );
}
