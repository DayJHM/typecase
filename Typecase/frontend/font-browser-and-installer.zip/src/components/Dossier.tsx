import { EXISTING, REQS, STACK } from "../data/catalog";

export default function Dossier() {
  const winner = STACK[0];
  return (
    <>
      {/* ——— does it exist? ——— */}
      <section id="dossier" className="mt-24 border-t border-[#14110e] pt-6">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid gap-10 lg:grid-cols-[260px_1fr]">
            <div className="lg:sticky lg:top-8 lg:self-start">
              <p className="lab text-[#c8341e]">Dossier · one</p>
              <h2 className="disp mt-2 text-[44px] leading-[0.95] tracking-tight">
                Does this
                <br />
                already
                <br />
                exist?
              </h2>
              <p className="mt-4 max-w-[30ch] text-[14px] leading-relaxed text-[#8a8072]">
                Yes — six times over, and each one answers a different half of your question. Nothing yet does
                browse, test, pull and set in one small package on Windows.
              </p>
            </div>

            <ul>
              {EXISTING.map((e) => (
                <li
                  key={e.name}
                  className="group grid grid-cols-1 gap-x-8 gap-y-1 border-b border-[#d8d0c2] py-5 md:grid-cols-[minmax(0,240px)_1fr]"
                >
                  <div>
                    <h3 className="disp text-[30px] leading-none transition-transform duration-200 group-hover:translate-x-1">
                      {e.name}
                    </h3>
                    <p className="lab mt-2 text-[#8a8072]">
                      {e.kind} · {e.platform}
                    </p>
                    <p className="lab num mt-1 text-[#c8341e]">{e.price}</p>
                  </div>
                  <p className="max-w-[62ch] self-center text-[15px] leading-relaxed">{e.note}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* ——— is it heavy? ——— */}
      <section className="mt-24">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid gap-10 lg:grid-cols-[260px_1fr]">
            <div className="lg:sticky lg:top-8 lg:self-start">
              <p className="lab text-[#c8341e]">Dossier · two</p>
              <h2 className="disp mt-2 text-[44px] leading-[0.95] tracking-tight">
                Is it a
                <br />
                heavy
                <br />
                program?
              </h2>
              <p className="mt-4 max-w-[30ch] text-[14px] leading-relaxed text-[#8a8072]">
                Only if you ship a browser to render four buttons. A font utility is a catalogue, a cache, a
                downloader and one call into the system text stack. Everything else is weight you chose.
              </p>
            </div>

            <div className="min-w-0">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] border-collapse text-left">
                  <thead>
                    <tr className="border-y border-[#14110e]">
                      <th className="lab py-2 pr-4">Build in</th>
                      <th className="lab py-2 pr-4 text-right">Installer</th>
                      <th className="lab py-2 pr-4 text-right">Idle RAM</th>
                      <th className="lab py-2 pr-4 text-right">Cold start</th>
                      <th className="lab py-2">Verdict</th>
                    </tr>
                  </thead>
                  <tbody>
                    {STACK.map((s, i) => (
                      <tr
                        key={s.lang}
                        className={`border-b border-[#d8d0c2] align-top ${i === 0 ? "bg-[#e9e2d5]" : ""}`}
                      >
                        <th scope="row" className="py-4 pr-4 text-[17px] font-normal">
                          <span className={i === 0 ? "border-b-2 border-[#c8341e] pb-0.5" : ""}>{s.lang}</span>
                          {i === 0 && <span className="lab ml-2 text-[#c8341e]">recommended</span>}
                        </th>
                        <td className="num py-4 pr-4 text-right text-[15px]">{s.size}</td>
                        <td className="num py-4 pr-4 text-right text-[15px]">{s.ram}</td>
                        <td className="num py-4 pr-4 text-right text-[15px]">{s.cold}</td>
                        <td className="py-4 text-[13.5px] leading-relaxed text-[#8a8072]">{s.note}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="lab mt-3 text-[#8a8072]">
                Figures are typical release builds on a 2021 laptop, x64, Windows 11 23H2. Ranges, not promises.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ——— the verdict, printed on the black page ——— */}
      <section id="verdict" className="relative mt-24 overflow-hidden bg-[#14110e] text-[#f2ede4]">
        <img
          src="images/press-bed.jpg"
          alt=""
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35 mix-blend-luminosity"
          onError={(e) => ((e.currentTarget.style.display = "none"), undefined)}
        />
        <div className="pointer-events-none absolute inset-0 bg-[#14110e]/55" />
        <div className="relative mx-auto max-w-[1400px] px-5 py-24 lg:px-10">
          <p className="lab text-[#c8341e]">Dossier · three — the answer</p>
          <h2 className="disp mt-4 max-w-[16ch] text-[clamp(44px,7.5vw,116px)] leading-[0.88] tracking-tight">
            Rust, over Tauri, over the browser that is already there.
          </h2>

          <div className="mt-14 grid gap-10 md:grid-cols-3">
            {[
              {
                h: "The shell",
                b: "Tauri 2 renders the interface through WebView2 — the engine Windows 10 1809+ and every Windows 11 already ship — so you never bundle Chromium. Your installer is one Rust binary plus a small asset bundle: 6–12 MB, signed, and it runs from a USB stick.",
                k: ["tauri 2", "webview2 evergreen", "rustc, LTO + strip"],
              },
              {
                h: "The type engine",
                b: "Read the files yourself rather than asking an OS dialog. ttf-parser reads names, tables and variation axes in microseconds; font-kit enumerates what is already installed and renders through DirectWrite; ab_glyph shapes the preview. The library is one HTTP cache and a zip reader.",
                k: ["ttf-parser", "font-kit", "ab_glyph", "reqwest", "zip-extract"],
              },
              {
                h: "The install",
                b: "Per-user is a file copy into %LOCALAPPDATA%\\Microsoft\\Windows\\Fonts plus one REG_SZ under HKCU\\...\\Fonts. Call AddFontResourceExW with FR_PRIVATE and broadcast WM_FONTCHANGE so open apps pick it up without a reboot. No service, no tray agent, no startup entry.",
                k: ["windows crate", "AddFontResourceExW", "WM_FONTCHANGE"],
              },
            ].map((c) => (
              <div key={c.h} className="border-t border-[#f2ede4]/25 pt-4">
                <h3 className="disp text-[30px] leading-none">{c.h}</h3>
                <p className="mt-3 text-[14.5px] leading-relaxed text-[#f2ede4]/72">{c.b}</p>
                <ul className="mt-4 flex flex-wrap gap-x-3 gap-y-1">
                  {c.k.map((k) => (
                    <li key={k} className="lab text-[#c8341e]">
                      {k}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <p className="mt-16 max-w-[70ch] text-[17px] leading-relaxed text-[#f2ede4]/85">
            <span className="disp text-[22px]">In short:</span> {winner.size} on disk, {winner.ram} sitting idle,
            and it opens before your finger leaves the key. The font library is cacheable, so browse and test work
            on a train; only pulling a new family needs the network. If you would rather not write it, NexusFont
            is the 4 MB answer today and FontBase is the comfortable one.
          </p>
        </div>
      </section>

      {/* ——— requirements ——— */}
      <section className="mt-24">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid gap-10 lg:grid-cols-[260px_1fr]">
            <div>
              <p className="lab text-[#c8341e]">Dossier · four</p>
              <h2 className="disp mt-2 text-[44px] leading-[0.95] tracking-tight">Requirements</h2>
              <p className="mt-4 max-w-[30ch] text-[14px] leading-relaxed text-[#8a8072]">
                For the utility described above — browse, test, pull and set — on Windows 10 and 11.
              </p>
            </div>
            <dl className="grid gap-x-10 sm:grid-cols-2">
              {REQS.map(([k, v]) => (
                <div key={k} className="border-t border-[#d8d0c2] py-4">
                  <dt className="lab text-[#8a8072]">{k}</dt>
                  <dd className="mt-1.5 max-w-[46ch] text-[15px] leading-relaxed">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>
    </>
  );
}
