import { useEffect, useLayoutEffect, useRef, useState } from "react";
import type { Face, Preset } from "../data/catalog";
import { CATALOG, INSTALL_PER_USER, PRESETS } from "../data/catalog";
import { copyText, cssSnippet, downloadUrl, loadFace, specimenUrl } from "../lib/fonts";

const WATERFALL = [12, 16, 21, 28, 37, 49, 65, 87];

function Gauge({ size }: { size: number }) {
  const pct = (size - 12) / (200 - 12);
  return (
    <div className="flex items-end gap-[3px]" aria-hidden="true">
      {Array.from({ length: 41 }).map((_, i) => (
        <span
          key={i}
          className={`w-px transition-all duration-150 ${i / 40 <= pct ? "bg-[#c8341e]" : "bg-[#d8d0c2]"}`}
          style={{ height: i % 5 === 0 ? 11 : 5 }}
        />
      ))}
    </div>
  );
}

function CopyBtn({ label, getText }: { label: string; getText: () => string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={async () => {
        const ok = await copyText(getText());
        setDone(ok);
        window.setTimeout(() => setDone(false), 1600);
      }}
      className={`lab border px-3 py-2 transition-colors duration-150 ${
        done
          ? "border-[#c8341e] bg-[#c8341e] text-[#f2ede4]"
          : "border-[#14110e] hover:bg-[#14110e] hover:text-[#f2ede4]"
      }`}
    >
      {done ? "Copied ✓" : label}
    </button>
  );
}

export default function Sheet({
  face,
  preset,
  onPreset,
  onPair,
}: {
  face: Face;
  preset: Preset;
  onPreset: (id: string) => void;
  onPair: (family: string) => void;
}) {
  const pair = CATALOG.find((f) => f.n === face.p);
  const [size, setSize] = useState(preset.size);
  const [weight, setWeight] = useState(preset.weight);
  const [track, setTrack] = useState(preset.track);
  const [lead, setLead] = useState(preset.lead);
  const [typed, setTyped] = useState("");
  const [revision, setRevision] = useState(0);
  const [status, setStatus] = useState<"setting" | "ok" | "error">("setting");
  const [showInstall, setShowInstall] = useState(false);

  const lineRef = useRef<HTMLDivElement>(null);
  const textRef = useRef(preset.display);

  useEffect(() => {
    setSize(preset.size);
    setWeight(preset.weight);
    setTrack(preset.track);
    setLead(preset.lead);
    textRef.current = preset.display;
    setTyped("");
    setRevision((r) => r + 1);
  }, [preset]);

  useEffect(() => {
    const lo = Math.min(...face.w);
    const hi = Math.max(...face.w);
    // keep the requested weight inside what this family actually ships
    setWeight((w) => Math.min(Math.max(w, lo), hi));
    setStatus("setting");
    setRevision((r) => r + 1);
    loadFace(face.n, face.w, !!face.i).then((r) => setStatus(r === "ok" ? "ok" : "error"));
  }, [face]);

  useLayoutEffect(() => {
    const el = lineRef.current;
    if (el && el.textContent !== textRef.current) el.textContent = textRef.current;
  }, [revision]);

  const sample = typed.trim() ? typed.trim() : preset.display;
  const wMin = Math.min(...face.w);
  const wMax = Math.max(...face.w);

  return (
    <section className="min-w-0">
      {/* ————— composing stick ————— */}
      <div className="sticky top-0 z-20 -mx-5 mb-8 bg-[#f2ede4]/95 px-5 pt-5 pb-3 backdrop-blur-[2px] lg:-mx-10 lg:px-10">
        <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-[#14110e] pb-2">
          <span className="lab text-[#c8341e]">Now setting</span>
          <span className="disp text-[22px] leading-none">{face.n}</span>
          <span className="lab text-[#8a8072]">
            {face.c} · {face.d} · {face.y} · {face.s} styles · SIL OFL 1.1
          </span>
          <span className="lab ml-auto flex items-center gap-4 text-[#8a8072]">
            {status === "ok" ? "◧ webfont set" : status === "setting" ? "◔ fetching…" : "◨ offline — system fallback"}
            <a href="#index" className="text-[#c8341e] underline underline-offset-4 lg:hidden">
              Change face ↓
            </a>
          </span>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-x-8 gap-y-3 md:grid-cols-4">
          <label className="block">
            <span className="lab flex items-baseline justify-between text-[#8a8072]">
              Size <b className="num text-[#c8341e]">{size}px</b>
            </span>
            <input type="range" min={12} max={200} step={1} value={size} onChange={(e) => setSize(+e.target.value)} />
          </label>
          <label className="block">
            <span className="lab flex items-baseline justify-between text-[#8a8072]">
              Weight <b className="num text-[#c8341e]">{wMax === wMin ? "single" : weight}</b>
            </span>
            <input
              type="range"
              min={wMin}
              max={wMax}
              step={100}
              value={weight}
              disabled={wMax === wMin}
              onChange={(e) => setWeight(+e.target.value)}
            />
          </label>
          <label className="block">
            <span className="lab flex items-baseline justify-between text-[#8a8072]">
              Tracking <b className="num text-[#c8341e]">{track.toFixed(3)}em</b>
            </span>
            <input type="range" min={-0.05} max={0.2} step={0.005} value={track} onChange={(e) => setTrack(+e.target.value)} />
          </label>
          <label className="block">
            <span className="lab flex items-baseline justify-between text-[#8a8072]">
              Leading <b className="num text-[#c8341e]">{lead.toFixed(2)}</b>
            </span>
            <input type="range" min={0.8} max={2} step={0.01} value={lead} onChange={(e) => setLead(+e.target.value)} />
          </label>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1">
          <span className="lab text-[#8a8072]">Set for</span>
          {PRESETS.map((p0) => {
            const id = p0.id;
            const on = preset.id === id;
            return (
              <button
                key={id}
                onClick={() => onPreset(id)}
                className={`lab border-b transition-colors duration-150 ${
                  on
                    ? "border-[#c8341e] text-[#14110e]"
                    : "border-transparent text-[#8a8072] hover:border-[#d8d0c2] hover:text-[#14110e]"
                }`}
              >
                {p0.label}
              </button>
            );
          })}
        </div>
        <p className="lab mt-2 text-[#8a8072]">
          {preset.use} — <span className="text-[#c8341e]">{preset.advice}</span>
        </p>
      </div>

      {/* ————— the specimen sheet ————— */}
      <div key={revision} className="setline">
        <div
          ref={lineRef}
          contentEditable
          suppressContentEditableWarning
          spellCheck={false}
          role="textbox"
          aria-label={`Editable specimen line in ${face.n}`}
          data-ph="Type here…"
          onInput={(e) => {
            textRef.current = (e.target as HTMLElement).textContent ?? "";
            setTyped(textRef.current);
          }}
          className="min-h-[0.6em] break-words hyphens-none"
          style={{
            fontFamily: `"${face.n}", "Bodoni Moda", Georgia, serif`,
            fontSize: `${size}px`,
            fontWeight: weight,
            letterSpacing: `${track}em`,
            lineHeight: lead,
          }}
        />
      </div>

      <div className="mt-3 flex items-end justify-between gap-6 border-b border-[#14110e] pb-2">
        <Gauge size={size} />
        <span className="lab num shrink-0 text-[#c8341e]">
          {size} pt · {weight} · {preset.label.toUpperCase()}
        </span>
      </div>

      {/* ————— waterfall ————— */}
      <div key={`wf-${face.n}`} className="mt-8 border-t border-[#d8d0c2] pt-4">
        <h3 className="lab text-[#8a8072]">Waterfall — same line, ascending body</h3>
        <div className="mt-3 space-y-1">
          {WATERFALL.map((s, i) => (
            <div
              key={s}
              className="setline flex items-baseline gap-4 border-b border-[#d8d0c2] pb-1"
              style={{ animationDelay: `${i * 22}ms` }}
            >
              <span className="lab num w-8 shrink-0 text-right text-[#c8341e]">{s}</span>
              <span
                className="min-w-0 flex-1 truncate"
                style={{
                  fontFamily: `"${face.n}", "Bodoni Moda", Georgia, serif`,
                  fontSize: `${s}px`,
                  fontWeight: weight,
                  lineHeight: 1.25,
                }}
              >
                {sample}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ————— body block, set to a 62-character measure ————— */}
      <div className="mt-10 border-t border-[#14110e] pt-5">
        <h3 className="lab text-[#8a8072]">Text block — {preset.label}</h3>
        <div
          key={`body-${face.n}`}
          className="setline mt-4 gap-10 md:columns-2"
          style={{
            fontFamily: `"${face.n}", "Bodoni Moda", Georgia, serif`,
            fontSize: "17.5px",
            fontWeight: 400,
            lineHeight: 1.6,
          }}
        >
          {preset.body.map((para, i) => (
            <p key={i} className="mb-4 max-w-[62ch] break-inside-avoid">
              {para}
            </p>
          ))}
        </div>
      </div>

      {/* ————— glyph case ————— */}
      <div className="mt-10 overflow-hidden border-y border-[#d8d0c2] py-4">
        <span
          className="block whitespace-nowrap"
          style={{
            fontFamily: `"${face.n}", "Bodoni Moda", Georgia, serif`,
            fontSize: "34px",
            fontWeight: 500,
            letterSpacing: "0.02em",
          }}
        >
          ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0123456789 &amp;@#$€£%§¶ ffi ft 1lI0O
        </span>
      </div>

      {/* ————— specimen note + pairing ————— */}
      <div className="mt-10 grid gap-8 border-t border-[#14110e] pt-5 md:grid-cols-2">
        <div>
          <h3 className="lab text-[#8a8072]">Specimen note</h3>
          <p className="disp mt-2 max-w-[38ch] text-[24px] leading-[1.25] italic">{face.t}</p>
        </div>
        <div>
          <h3 className="lab text-[#8a8072]">Sets well with</h3>
          {pair ? (
            <button
              onClick={() => onPair(pair.n)}
              className="disp mt-2 block border-b-2 border-[#c8341e] pb-0.5 text-left text-[24px] leading-tight transition-transform duration-150 hover:translate-x-1"
            >
              {pair.n} →
            </button>
          ) : (
            <p className="disp mt-2 text-[24px] leading-tight">{face.p}</p>
          )}
          <p className="lab mt-3 max-w-[34ch] text-[#8a8072]">
            One family for the display line, its companion for the text block. Two families maximum per document.
          </p>
        </div>
      </div>

      {/* ————— retrieval ————— */}
      <div className="mt-8 flex flex-wrap items-center gap-2">
        <a
          href={downloadUrl(face.n)}
          className="lab border border-[#c8341e] bg-[#c8341e] px-3 py-2 text-[#f2ede4] transition-colors duration-150 hover:bg-[#14110e] hover:border-[#14110e]"
        >
          ↓ Pull family (.zip · TTF + OFL)
        </a>
        <CopyBtn label="Copy CSS link" getText={() => cssSnippet(face.n, face.w)} />
        <CopyBtn label="Copy family name" getText={() => face.n} />
        <a
          href={specimenUrl(face.n)}
          target="_blank"
          rel="noreferrer"
          className="lab border border-[#14110e] px-3 py-2 transition-colors duration-150 hover:bg-[#14110e] hover:text-[#f2ede4]"
        >
          Google Fonts page ↗
        </a>
        <button
          onClick={() => setShowInstall((s) => !s)}
          aria-expanded={showInstall}
          className="lab border border-[#14110e] px-3 py-2 transition-colors duration-150 hover:bg-[#14110e] hover:text-[#f2ede4]"
        >
          {showInstall ? "Close installer notes ×" : "Set on Windows 10 / 11 +"}
        </button>
      </div>
      <p className="lab mt-2 max-w-[62ch] text-[#8a8072]">
        Windows installs .ttf, .otf and .ttc — never .woff2. The .zip is the correct artefact: it carries the
        static and variable TTFs and the SIL Open Font Licence text.
      </p>

      {showInstall && (
        <div className="slipin mt-6 bg-[#14110e] px-6 py-8 text-[#f2ede4] lg:px-10">
          <h3 className="lab text-[#c8341e]">Setting {face.n} — three routes</h3>
          <div className="mt-6 grid gap-8 md:grid-cols-3">
            {[
              {
                n: "01",
                h: "Just you (no admin)",
                b: "Unzip, then copy the .ttf files into %LOCALAPPDATA%\\Microsoft\\Windows\\Fonts. Windows 11 also accepts a drag onto Settings › Personalisation › Fonts. The face is registered under HKCU and is invisible to other accounts.",
              },
              {
                n: "02",
                h: "Every account",
                b: "Right-click a .ttf and choose Install for all users — this writes to C:\\Windows\\Fonts and needs elevation. Adobe and Affinity apps only rescan their font list at launch, so restart them.",
              },
              {
                n: "03",
                h: "Scripted, repeatable",
                b: "The PowerShell below copies the files and writes the registry value in one pass — the way to set up a new machine, or to keep a design team identical.",
              },
            ].map((s) => (
              <div key={s.n} className="border-t border-[#f2ede4]/25 pt-3">
                <span className="num text-[#c8341e]">{s.n}</span>
                <h4 className="disp mt-1 text-[22px] leading-tight">{s.h}</h4>
                <p className="mt-2 text-[13.5px] leading-relaxed text-[#f2ede4]/70">{s.b}</p>
              </div>
            ))}
          </div>
          <pre className="mono mt-8 overflow-x-auto border border-[#f2ede4]/20 bg-[#0b0908] p-4 text-[11.5px] leading-[1.65] text-[#f2ede4]/75">
            {INSTALL_PER_USER}
          </pre>
          <p className="lab mt-3 text-[#f2ede4]/50">
            Verify afterwards: Settings › Fonts, or ask DirectWrite for the family name from your app.
          </p>
        </div>
      )}
    </section>
  );
}
