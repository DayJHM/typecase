export type Cat = "Serif" | "Sans" | "Display" | "Mono" | "Script";

export type Face = {
  n: string; // family name, as Google Fonts spells it
  c: Cat;
  d: string; // designer / foundry
  y: number; // first release on Google Fonts
  s: number; // styles in the family
  w: number[]; // weights we ask the CSS2 API for
  i?: boolean; // italics available
  t: string; // specimen note — what the face is actually good at
  p: string; // sets well with
};

/* Curated index — 60 faces. Names, designers, years and categories are real.
   The loader asks the CSS2 API for the listed weights and degrades gracefully. */
export const CATALOG: Face[] = [
  { n: "Inter", c: "Sans", d: "Rasmus Andersson", y: 2016, s: 18, w: [300, 400, 500, 600, 700], i: true, t: "Neutral workhorse with tall x-height; tabular figures by default.", p: "Newsreader" },
  { n: "Bodoni Moda", c: "Serif", d: "Owen Earl / indestructible type", y: 2020, s: 12, w: [400, 500, 700, 900], i: true, t: "Didone with hairline serifs — poster sizes only, never below 16 px.", p: "IBM Plex Mono" },
  { n: "Fraunces", c: "Serif", d: "Undercase Type", y: 2020, s: 28, w: [300, 400, 600, 700, 900], i: true, t: "Wonky old-style with SOFT and WONK axes; warm at display size.", p: "Work Sans" },
  { n: "Newsreader", c: "Serif", d: "Production Type", y: 2020, s: 14, w: [300, 400, 500, 600, 700], i: true, t: "Screen-first text serif; optical sizes from caption to headline.", p: "Public Sans" },
  { n: "Literata", c: "Serif", d: "TypeTogether", y: 2015, s: 18, w: [300, 400, 500, 600, 700], i: true, t: "Built for long-form reading on screen — the ebook default.", p: "Alegreya Sans" },
  { n: "EB Garamond", c: "Serif", d: "Georg Duffner / Octavio Pardo", y: 2011, s: 12, w: [400, 500, 600, 700, 800], i: true, t: "Garalde revival; tight colour and old-style figures for essays.", p: "Inter" },
  { n: "Cormorant Garamond", c: "Serif", d: "Christian Thalmann", y: 2015, s: 30, w: [300, 400, 500, 600, 700], i: true, t: "Delicate, high-contrast Garalde. Beautiful at 24 pt+, fragile at 10 pt.", p: "Karla" },
  { n: "Libre Baskerville", c: "Serif", d: "Impallari Type", y: 2012, s: 4, w: [400, 700], i: true, t: "Widened and darkened for body text on the web. Very safe.", p: "Source Sans 3" },
  { n: "Playfair Display", c: "Serif", d: "Claus Eggers Sørensen", y: 2011, s: 12, w: [400, 500, 700, 900], i: true, t: "Transitional didone for editorial headlines and decks.", p: "Source Sans 3" },
  { n: "Spectral", c: "Serif", d: "Production Type", y: 2017, s: 14, w: [200, 300, 400, 500, 600, 700, 800], i: true, t: "Screen-optimised text serif with a wide range of weights.", p: "Karla" },
  { n: "Source Serif 4", c: "Serif", d: "Frank Grießhammer / Adobe", y: 2012, s: 20, w: [300, 400, 500, 600, 700, 900], i: true, t: "Companion to Source Sans and Source Code — a full document system.", p: "Source Sans 3" },
  { n: "Merriweather", c: "Serif", d: "Sorkin Type", y: 2010, s: 16, w: [300, 400, 700, 900], i: true, t: "Heavy serifs, large x-height — survives bad screens and small sizes.", p: "Open Sans" },
  { n: "Lora", c: "Serif", d: "Cyreal", y: 2011, s: 8, w: [400, 500, 600, 700], i: true, t: "Calligraphic brushwork under a calm body; good for blog text.", p: "Muli" },
  { n: "PT Serif", c: "Serif", d: "ParaType", y: 2010, s: 8, w: [400, 700], i: true, t: "Public Type project — pan-Cyrillic, made for state documents.", p: "PT Sans" },
  { n: "Crimson Text", c: "Serif", d: "Sebastian Kosch", y: 2011, s: 6, w: [400, 600, 700], i: true, t: "Jan Tschichold's Penguin legacy in a small book face.", p: "Gill Sans alternative" },
  { n: "Vollkorn", c: "Serif", d: "Friedrich Althausen", y: 2009, s: 8, w: [400, 500, 600, 700, 800, 900], i: true, t: "Dark, hearty bread-and-butter text face.", p: "Karla" },
  { n: "Alegreya", c: "Serif", d: "Huerta Tipográfica", y: 2011, s: 12, w: [400, 500, 600, 700, 800, 900], i: true, t: "Dynamic, calligraphic rhythm; designed for literature.", p: "Alegreya Sans" },
  { n: "Bitter", c: "Serif", d: "Huerta Tipográfica", y: 2011, s: 12, w: [100, 200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Slab serif engineered for LCD body text.", p: "Open Sans" },
  { n: "Old Standard TT", c: "Serif", d: "Alexey Kryukov", y: 2009, s: 6, w: [400, 700], i: true, t: "Late-19th-century book look; scholarly footnotes and citations.", p: "Roboto Condensed" },
  { n: "Cardo", c: "Serif", d: "David J. Perry", y: 2002, s: 4, w: [400, 700], i: true, t: "Scholarly face with Greek, Hebrew and broad Unicode coverage.", p: "Inter" },
  { n: "Cinzel", c: "Display", d: "Natanael Gama", y: 2012, s: 6, w: [400, 500, 600, 700, 800, 900], t: "Roman inscriptional capitals. Titles and certificates only.", p: "EB Garamond" },
  { n: "Marcellus", c: "Display", d: "Astigmatic", y: 2011, s: 2, w: [400], t: "Refined Trajan-like capitals with a single weight.", p: "Cardo" },
  { n: "Abril Fatface", c: "Display", d: "TypeTogether", y: 2011, s: 2, w: [400], t: "Fat didone for magazine covers and one-word headlines.", p: "Lato" },
  { n: "Instrument Serif", c: "Serif", d: "Instrument", y: 2023, s: 4, w: [400], i: true, t: "Modern high-contrast display serif. Tight, tall, fashionable.", p: "Instrument Sans" },
  { n: "Libre Caslon Display", c: "Display", d: "Impallari Type", y: 2018, s: 2, w: [400], t: "Caslon cut for the masthead size of a broadsheet.", p: "Libre Franklin" },
  { n: "Archivo", c: "Sans", d: "Omnibus-Type", y: 2012, s: 18, w: [300, 400, 500, 600, 700, 800, 900], i: true, t: "Roboto-ish grotesque built for high-performance print and UI.", p: "Bodoni Moda" },
  { n: "Work Sans", c: "Sans", d: "Wei Huang", y: 2015, s: 18, w: [300, 400, 500, 600, 700, 800], i: true, t: "Optimised for body text on screen at 14 px and above.", p: "Fraunces" },
  { n: "Space Grotesk", c: "Sans", d: "Florian Karsten", y: 2018, s: 7, w: [300, 400, 500, 600, 700], t: "Proportionally-spaced grotesque with quirky terminals.", p: "Space Mono" },
  { n: "DM Sans", c: "Sans", d: "Colophon Foundry", y: 2019, s: 12, w: [300, 400, 500, 600, 700, 800, 900], i: true, t: "Low-contrast geometric, tuned for small UI copy.", p: "DM Serif Display" },
  { n: "DM Serif Display", c: "Display", d: "Colophon Foundry", y: 2019, s: 4, w: [400], i: true, t: "Elegant didone display; pairs instantly with DM Sans.", p: "DM Sans" },
  { n: "IBM Plex Sans", c: "Sans", d: "Mike Abbink / Bold Monday", y: 2017, s: 16, w: [300, 400, 500, 600, 700], i: true, t: "Engineered grotesque with a matching serif and mono — a whole system.", p: "IBM Plex Serif" },
  { n: "IBM Plex Serif", c: "Serif", d: "Mike Abbink / Bold Monday", y: 2017, s: 14, w: [300, 400, 500, 600, 700], i: true, t: "Slab-ish transitional for technical documentation.", p: "IBM Plex Sans" },
  { n: "IBM Plex Mono", c: "Mono", d: "Mike Abbink / Bold Monday", y: 2017, s: 14, w: [300, 400, 500, 600, 700], i: true, t: "Fixed-pitch with unambiguous 1/l/I — labels and code.", p: "IBM Plex Sans" },
  { n: "JetBrains Mono", c: "Mono", d: "Philipp Nurullin / JetBrains", y: 2020, s: 16, w: [100, 200, 300, 400, 500, 600, 700, 800], i: true, t: "Tall x-height in code; increased letterform distinctions.", p: "Inter" },
  { n: "Roboto Mono", c: "Mono", d: "Christian Robertson", y: 2015, s: 14, w: [100, 200, 300, 400, 500, 600, 700], i: true, t: "Dual-pitch grotesque mono; safe in every editor.", p: "Roboto" },
  { n: "Source Code Pro", c: "Mono", d: "Paul D. Hunt / Adobe", y: 2012, s: 14, w: [200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "The code half of the Source superfamily.", p: "Source Serif 4" },
  { n: "Space Mono", c: "Mono", d: "Colophon Foundry", y: 2016, s: 8, w: [400, 700], i: true, t: "1960s-ish fixed pitch with eccentric curves. Labels and captions.", p: "Space Grotesk" },
  { n: "Inconsolata", c: "Mono", d: "Raph Levien", y: 2006, s: 10, w: [200, 300, 400, 500, 600, 700, 800, 900], t: "Humanist mono — narrow, gentle, good for long listings.", p: "Lora" },
  { n: "Courier Prime", c: "Mono", d: "Quote-Unquote Apps", y: 2013, s: 6, w: [400, 700], i: true, t: "Cut of Courier for screenplays. Use it for scripts.", p: "Libre Baskerville" },
  { n: "Anonymous Pro", c: "Mono", d: "Mark Simonson", y: 2009, s: 4, w: [400, 700], i: true, t: "Fixed pitch designed for the terminal and for coding in bed.", p: "Cardo" },
  { n: "Fira Sans", c: "Sans", d: "Erik Spiekermann / Carrois", y: 2011, s: 18, w: [300, 400, 500, 600, 700, 800, 900], i: true, t: "Firefox's humanist sans; excellent at 12–14 px in dense UI.", p: "Fira Code" },
  { n: "Karla", c: "Sans", d: "Jonny Pinhorn", y: 2012, s: 14, w: [300, 400, 500, 600, 700, 800], i: true, t: "Grotesque with odd, spiky details. Good next to a serif.", p: "Spectral" },
  { n: "Manrope", c: "Sans", d: "Mikhail Sharanda", y: 2018, s: 14, w: [200, 300, 400, 500, 600, 700, 800], i: true, t: "Semi-geometric with open apertures; product UI and decks.", p: "Lora" },
  { n: "Plus Jakarta Sans", c: "Sans", d: "Tokotype", y: 2020, s: 16, w: [200, 300, 400, 500, 600, 700, 800], i: true, t: "Crisp grotesque with tight spacing; strong in dashboards.", p: "Source Serif 4" },
  { n: "Public Sans", c: "Sans", d: "US Web Design System", y: 2019, s: 16, w: [100, 200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Neutral, accessible, civic — the US government's house face.", p: "Merriweather" },
  { n: "Atkinson Hyperlegible", c: "Sans", d: "Braille Institute / Applied Design", y: 2020, s: 6, w: [400, 700], i: true, t: "Letters disambiguated for low vision. The accessibility pick.", p: "Literata" },
  { n: "Red Hat Display", c: "Sans", d: "MCKL", y: 2019, s: 10, w: [300, 400, 500, 600, 700, 800, 900], i: true, t: "Rounded geometric for headlines; Red Hat Text for body.", p: "Red Hat Text" },
  { n: "Barlow", c: "Sans", d: "Jeremy Tribby", y: 2017, s: 27, w: [100, 200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Slightly rounded grotesk with widths and italics — 27 styles.", p: "Bitter" },
  { n: "Asap", c: "Sans", d: "Omnibus-Type", y: 2011, s: 16, w: [300, 400, 500, 600, 700, 800], i: true, t: "Condensed-friendly grotesque that saves line length.", p: "Asap Condensed" },
  { n: "Chivo", c: "Sans", d: "Omnibus-Type", y: 2011, s: 16, w: [100, 200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Grotesque with real grit at heavy weights.", p: "Bodoni Moda" },
  { n: "Epilogue", c: "Sans", d: "Tyler Finck / Etcetera Type Co", y: 2019, s: 18, w: [100, 200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Geometric with a wide range; loud at Black.", p: "Fraunces" },
  { n: "Bricolage Grotesque", c: "Display", d: "Mathieu Triay", y: 2022, s: 14, w: [200, 300, 400, 500, 600, 700, 800], t: "Variable width and optical size — characterful UI and posters.", p: "Newsreader" },
  { n: "Wix Madefor Display", c: "Display", d: "Emi Takahashi / Wix", y: 2023, s: 10, w: [400, 500, 600, 700, 800], i: true, t: "Built for hero headlines with a matching text cut.", p: "Wix Madefor Text" },
  { n: "Instrument Sans", c: "Sans", d: "Instrument", y: 2023, s: 10, w: [400, 500, 600, 700], i: true, t: "Neutral grotesque cut to sit under Instrument Serif.", p: "Instrument Serif" },
  { n: "Noto Serif", c: "Serif", d: "Google / Monotype", y: 2013, s: 74, w: [300, 400, 500, 600, 700], i: true, t: "The no-tofu family: 800+ scripts, 100+ writing systems.", p: "Noto Sans" },
  { n: "Noto Sans", c: "Sans", d: "Google / Monotype", y: 2013, s: 72, w: [300, 400, 500, 600, 700], i: true, t: "When the copy mixes Latin, Greek, Cyrillic and Devanagari.", p: "Noto Serif" },
  { n: "Oswald", c: "Display", d: "Vernon Adams", y: 2011, s: 6, w: [200, 300, 400, 500, 600, 700], t: "Condensed gothic for headline decks and posters.", p: "Lora" },
  { n: "Bebas Neue", c: "Display", d: "Ryoichi Tsunekawa / Dharma Type", y: 2010, s: 2, w: [400], t: "All-caps condensed. Set it huge or don't set it.", p: "Inter" },
  { n: "Anton", c: "Display", d: "Vernon Adams", y: 2011, s: 2, w: [400], t: "One heavy weight of condensed sans. Maximum impact.", p: "Roboto" },
  { n: "Poppins", c: "Sans", d: "Indian Type Foundry", y: 2014, s: 18, w: [300, 400, 500, 600, 700, 800, 900], i: true, t: "Perfect-circle geometric with Devanagari. Friendly product UI.", p: "Playfair Display" },
  { n: "Rubik", c: "Sans", d: "Hubert & Fischer / Meir Sadan", y: 2015, s: 10, w: [300, 400, 500, 600, 700, 800, 900], i: true, t: "Rounded corners, slightly condensed — good in chips and buttons.", p: "Roboto Slab" },
  { n: "Lato", c: "Sans", d: "Łukasz Dziedzic", y: 2010, s: 10, w: [100, 300, 400, 700, 900], i: true, t: "Semi-rounded humanist; the corporate-brochure default since 2010.", p: "Merriweather" },
  { n: "Open Sans", c: "Sans", d: "Steve Matteson", y: 2011, s: 12, w: [300, 400, 500, 600, 700, 800], i: true, t: "Optimised for print, web and mobile interfaces. Utterly neutral.", p: "Source Serif 4" },
  { n: "Montserrat", c: "Sans", d: "Julieta Ulanovsky", y: 2011, s: 18, w: [200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Urban typography of Buenos Aires; strong at ExtraBold.", p: "Playfair Display" },
  { n: "Roboto", c: "Sans", d: "Christian Robertson", y: 2011, s: 18, w: [100, 300, 400, 500, 700, 900], i: true, t: "Android's house grotesque. Mechanical, legible, everywhere.", p: "Roboto Slab" },
  { n: "Ubuntu", c: "Sans", d: "Dalton Maag", y: 2010, s: 10, w: [300, 400, 500, 700], i: true, t: "Distinctive loopless humanist; a whole OS in one family.", p: "Ubuntu Mono" },
  { n: "Josefin Sans", c: "Sans", d: "Santiago Orozco", y: 2010, s: 14, w: [100, 200, 300, 400, 500, 600, 700], i: true, t: "1920s geometric with a very high waist. Elegant in caps.", p: "Josefin Slab" },
  { n: "Raleway", c: "Sans", d: "Matt McInerney / Impallari Type", y: 2010, s: 18, w: [100, 200, 300, 400, 500, 600, 700, 800, 900], i: true, t: "Elegant thin-to-black grotesque with a swashy w.", p: "Lora" },
  { n: "Lobster", c: "Script", d: "Impallari Type", y: 2010, s: 2, w: [400], t: "The bold script that defined 2011. Signage and packaging only.", p: "Inter" },
  { n: "Pacifico", c: "Script", d: "Vernon Adams", y: 2011, s: 2, w: [400], t: "Brush script from surf culture. Logotypes, never body copy.", p: "Karla" },
  { n: "Caveat", c: "Script", d: "Impallari Type", y: 2015, s: 8, w: [400, 500, 600, 700], t: "Casual handwriting for annotations and margin notes.", p: "Inter" },
  { n: "Shadows Into Light", c: "Script", d: "Kimberly Geswein", y: 2011, s: 2, w: [400], t: "Pencil-like schoolbook hand. Worksheets and captions.", p: "Nunito" },
  { n: "Permanent Marker", c: "Display", d: "Font Diner", y: 2010, s: 2, w: [400], t: "Marker pen. Posters, stickers, one word at a time.", p: "Karla" },
  { n: "Rock Salt", c: "Script", d: "Nootype", y: 2010, s: 2, w: [400], t: "Nervous handwriting with wide spacing. Notes and titles.", p: "Work Sans" },
];

export const CATS: (Cat | "All")[] = ["All", "Serif", "Sans", "Display", "Mono", "Script"];

/* ---- The document presets: the actual question is "which face for which job" ---- */
export type Preset = {
  id: string;
  label: string;
  use: string;
  size: number;
  weight: number;
  track: number;
  lead: number;
  display: string;
  body: string[];
  advice: string;
};

export const PRESETS: Preset[] = [
  {
    id: "essay",
    label: "Academic essay",
    use: "Body 11 pt · 62 characters · ragged right",
    size: 96,
    weight: 400,
    track: -0.01,
    lead: 1.05,
    display: "A typeface is not a font",
    body: [
      "The face is the drawing of the alphabet, in all its weights and widths; the font is the delivery mechanism. Once a wooden tray of foundry sorts, later a film negative, now a file on a disk. When a 1920s specimen book lists forty-eight sizes of Caslon it is listing forty-eight fonts of one face, and the confusion that survives into the desktop era is a confusion between the work and its container.",
      "Set long-form text where the type disappears. Choose a text serif with an optical size axis, keep the measure between 60 and 72 characters, and let the line height follow the x-height rather than the point size. Save the contrast for the chapter opening.",
    ],
    advice: "Prefer a text-cut serif at 400. Avoid display faces below 16 px.",
  },
  {
    id: "cv",
    label: "Résumé / CV",
    use: "One page · 10.5 pt · parseable by ATS",
    size: 64,
    weight: 600,
    track: -0.02,
    lead: 1.1,
    display: "Marta Kovács — Product Designer",
    body: [
      "EXPERIENCE — Senior Product Designer, Kestrel Systems, Rotterdam · 2021–present. Led the redesign of the billing console used by 14,000 accounts; cut time-to-invoice from 9 minutes to 80 seconds. Built and documented a 240-component design system in Figma and React.",
      "EDUCATION — MA Information Design, Design Academy Eindhoven, 2016. SKILLS — Figma, React, TypeScript, DirectWrite, WCAG 2.2 AA, design systems, technical writing.",
    ],
    advice: "One family only. 10.5–11 pt, generous leading, no text below 9 pt, no colour-only meaning.",
  },
  {
    id: "poster",
    label: "Conference poster",
    use: "A1 · headline 400 pt · read at 3 m",
    size: 190,
    weight: 800,
    track: -0.03,
    lead: 0.92,
    display: "TYPE 26",
    body: [
      "SHEFFIELD · 14–16 NOVEMBER — Three days of punchcutting, parametric type and variable fonts. Speakers from Production Type, Bold Monday, Omnibus-Type and the St Bride Library. Punchcutting workshop on the Sunday, twelve places only.",
      "Early bird until 30 September. Tickets and programme at type26.example",
    ],
    advice: "Go extreme: 300 pt+ against 24 pt. Three lines maximum in the headline block.",
  },
  {
    id: "ui",
    label: "Product UI",
    use: "Interface 13–15 px · dense tables · WCAG AA",
    size: 56,
    weight: 500,
    track: -0.01,
    lead: 1.15,
    display: "Deployments",
    body: [
      "Empty state — No deployments yet. Connect a repository to publish your first build, or read the quickstart. Primary action: Connect repository. Secondary: Read the quickstart.",
      "Table — 1,284 rows · Sorted by updated · filter: status = failed. Column labels in tracked small caps at 11 px; all numerals tabular so the columns align down the page. Focus ring 2 px, 4.5:1 against every surface.",
    ],
    advice: "Sans with tabular figures on by default. Test at 125 % and 150 % Windows scaling.",
  },
  {
    id: "letter",
    label: "Newsletter",
    use: "Email · deck 32 pt · body 17 px",
    size: 84,
    weight: 400,
    track: -0.02,
    lead: 1.02,
    display: "The Set Rule",
    body: [
      "ISSUE 41 — Why your columns look cramped, and the one measurement that fixes it. Also this week: five variable fonts that finally ship decent italics, and a short defence of the humble comma.",
      "The deck carries the issue. Set it in the display cut at 32 pt, tight, two lines; then drop hard to the text cut at 17 px with a 1.6 line height. The jump is the whole hierarchy — you should not need a third weight.",
    ],
    advice: "Pair two cuts of one superfamily. Deck tight, body loose, one accent colour for links.",
  },
  {
    id: "deck",
    label: "Slide deck",
    use: "16:9 · 6 rows of text maximum",
    size: 130,
    weight: 700,
    track: -0.03,
    lead: 0.98,
    display: "Ship the small thing",
    body: [
      "One idea per slide. If a slide needs a paragraph, it is a document wearing a slide's clothes — export it as a PDF instead.",
      "Test the deck at the back of the room: if you cannot read the smallest line from eight metres away, it is caption material and belongs in the speaker notes.",
    ],
    advice: "Headline 90–130 pt, one weight, one accent. Never centre body copy.",
  },
];

/* ---- The dossier: real tools that already do this ---- */
export const EXISTING = [
  { name: "Google Fonts", kind: "Web app", platform: "Any browser", price: "Free", note: "Browse, test with your own text, download the whole family as a .zip of TTFs. No offline cache, no local library, no install step." },
  { name: "FontBase", kind: "Desktop manager", platform: "Win · macOS · Linux", price: "Free / €3 mo Pro", note: "Activation, tagging, and a Google Fonts tab you can install from without leaving the app. Built on Electron, so it is the heaviest in this list." },
  { name: "NexusFont", kind: "Desktop manager", platform: "Windows only", price: "Freeware", note: "Around 4 MB, runs portable from a stick, previews in one click, installs and uninstalls cleanly. Long-lived and still updated; the lightweight answer." },
  { name: "SkyFonts", kind: "Sync agent", platform: "Win · macOS", price: "Free", note: "Monotype's small background utility. Click a family on the Google Fonts site and it installs locally; remove it and the font uninstalls. No window to speak of." },
  { name: "Windows Font Viewer", kind: "Built in", platform: "Win 10 · Win 11", price: "Free", note: "Double-click any .ttf and Windows previews A–Z in three sizes with an Install button. Preview only — it will not browse a remote library." },
  { name: "Adobe Fonts", kind: "Service + agent", platform: "Win · macOS", price: "With Creative Cloud", note: "19,000+ licensed fonts, activated per app, but the library is not Google's and it wants the CC desktop agent running." },
];

export const STACK = [
  { lang: "Rust + Tauri 2", size: "6–12 MB", ram: "60–120 MB", cold: "0.2–0.4 s", note: "The zero-bloat answer. One small binary over the WebView2 already on Windows 10/11. Reach for font-kit and ttf-parser in the core." },
  { lang: "C# / .NET 8 + WinUI 3", size: "45–80 MB", ram: "90–160 MB", cold: "0.5–0.9 s", note: "Pure Microsoft stack, MSIX store distribution and DirectWrite interop are first-class. Bundle the runtime self-contained and the size roughly quadruples." },
  { lang: "C++ / Win32 + DirectWrite", size: "2–6 MB", ram: "25–60 MB", cold: "< 0.2 s", note: "Smallest and fastest possible. You also hand-roll the whole UI, the text shaping and the updater. Budget months, not days." },
  { lang: "Electron (Node + Chromium)", size: "90–180 MB", ram: "180–400 MB", cold: "1.0–2.5 s", note: "Fastest route to a polished interface — and exactly the weight you said you did not want. FontBase lives here." },
  { lang: "Go or Dart + webview", size: "15–30 MB", ram: "70–140 MB", cold: "0.3–0.6 s", note: "Middle ground. Fine, but the font-enumeration and install story is less mature than Rust's." },
];

export const REQS = [
  ["Operating system", "Windows 10 1809 (17763) or later, Windows 11 22H2+"],
  ["Runtime", "WebView2 Evergreen — preinstalled on Windows 11 and on Windows 10 since mid-2021"],
  ["Disk", "≈ 50 MB for the utility, plus whatever you cache from the library"],
  ["Memory", "Under 120 MB idle; a hundred cached families add tens of MB"],
  ["Network", "fonts.googleapis.com (CSS) · fonts.gstatic.com (files) · github.com/google/fonts (TTF source)"],
  ["GPU", "None. Text rendering is DirectWrite / ClearType, not WebGL"],
  ["Privileges", "None for per-user install. Writing to C:\\Windows\\Fonts needs elevation"],
  ["Licence", "Everything in the library ships under the SIL Open Font Licence 1.1 — free for print, web, apps and embedding"],
];

export const INSTALL_PER_USER = `# Per-user install — no admin rights required
$family = "Bodoni Moda"
$src    = "$env:USERPROFILE\\Downloads\\$family"
$dst    = "$env:LOCALAPPDATA\\Microsoft\\Windows\\Fonts"
$reg    = "HKCU:\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts"

New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item "$src\\*.ttf" $dst -Force

Get-ChildItem "$dst\\*.ttf" | ForEach-Object {
  $value = "$($_.BaseName) (TrueType)"
  New-ItemProperty -Path $reg -Name $value -Value $_.FullName -PropertyType String -Force | Out-Null
}

# broadcast the change so apps pick it up without a reboot
Add-Type -Namespace Win -Name Gdi -MemberDefinition '[DllImport("gdi32.dll")] public static extern int AddFontResourceEx(string lpszFileName, uint fl, System.IntPtr pdv);'
[Win.Gdi]::AddFontResourceEx("$dst\\$family-Regular.ttf", 0x10, [IntPtr]::Zero)`;
