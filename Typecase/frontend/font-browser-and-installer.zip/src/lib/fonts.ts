/* Google Fonts CSS2 loader — three-stage fallback so a family never fails to set:
   1. weights + italics   2. weights only   3. whatever Google serves by default */

const cache = new Map<string, Promise<"ok" | "error">>();

const slug = (f: string) => encodeURIComponent(f).replace(/%20/g, "+");

function mount(url: string, fallback?: string): Promise<"ok" | "error"> {
  return new Promise((resolve) => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = url;
    let settled = false;
    const done = (r: "ok" | "error") => {
      if (settled) return;
      settled = true;
      resolve(r);
    };
    const timer = window.setTimeout(() => done("error"), 7000);
    link.onload = () => {
      window.clearTimeout(timer);
      done("ok");
    };
    link.onerror = () => {
      window.clearTimeout(timer);
      link.remove();
      if (fallback) {
        mount(fallback).then(done);
      } else {
        done("error");
      }
    };
    document.head.appendChild(link);
  });
}

export function loadFace(family: string, weights: number[], italic = false): Promise<"ok" | "error"> {
  const key = family;
  const hit = cache.get(key);
  if (hit) return hit;

  const base = `https://fonts.googleapis.com/css2?family=${slug(family)}&display=swap`;
  const w = [...new Set(weights)].sort((a, b) => a - b).join(";");
  const wOnly = `https://fonts.googleapis.com/css2?family=${slug(family)}:wght@${w}&display=swap`;
  const full = italic
    ? `https://fonts.googleapis.com/css2?family=${slug(family)}:ital,wght@0,${w};1,${Math.min(400, w ? Number(w.split(";")[0]) : 400)}&display=swap`
    : wOnly;

  const p = mount(full, wOnly === full ? base : wOnly).catch(() => "error" as const);
  cache.set(key, p);
  return p;
}

export const specimenUrl = (family: string) =>
  `https://fonts.google.com/specimen/${encodeURIComponent(family).replace(/%20/g, "+")}`;

export const downloadUrl = (family: string) =>
  `https://fonts.google.com/download?family=${encodeURIComponent(family).replace(/%20/g, "+")}`;

export function cssSnippet(family: string, weights: number[]) {
  const w = [...new Set(weights)].sort((a, b) => a - b);
  const list = w.join(";");
  return `<!-- ${family} — SIL Open Font Licence 1.1 -->
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=${slug(family)}:wght@${list}&display=swap">

<style>
  :root { --font-${slug(family).toLowerCase().replace(/\+/g, "-")}: "${family}", Georgia, serif; }
  body { font-family: var(--font-${slug(family).toLowerCase().replace(/\+/g, "-")}); font-weight: 400; }
</style>`;
}

export async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {
      ok = false;
    }
    ta.remove();
    return ok;
  }
}
