import { useMemo, useState } from "react";
import Rail from "./components/Rail";
import Sheet from "./components/Sheet";
import Dossier from "./components/Dossier";
import { CATALOG, PRESETS, type Cat, type Face } from "./data/catalog";

export default function App() {
  const [selected, setSelected] = useState<Face>(CATALOG[1]);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<Cat | "All">("All");
  const [presetId, setPresetId] = useState("essay");

  const preset = PRESETS.find((p) => p.id === presetId) ?? PRESETS[0];

  const faces = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CATALOG.filter((f) => {
      if (cat !== "All" && f.c !== cat) return false;
      if (!q) return true;
      return (
        f.n.toLowerCase().includes(q) ||
        f.d.toLowerCase().includes(q) ||
        f.t.toLowerCase().includes(q) ||
        f.c.toLowerCase().includes(q)
      );
    }).sort((a, b) => a.n.localeCompare(b.n));
  }, [query, cat]);

  return (
    <div className="grain min-h-screen">
      {/* ——— masthead ——— */}
      <header className="mx-auto max-w-[1400px] px-5 pt-6 lg:px-10">
        <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b border-[#14110e] pb-2">
          <span className="lab">Typecase — specimen &amp; retrieval utility</span>
          <span className="lab text-[#8a8072]">Google Fonts library · SIL OFL 1.1</span>
          <span className="lab num text-[#c8341e]">Windows 10 / 11</span>
        </div>

        {/* ——— hero: headline set against the composing stick ——— */}
        <div className="relative">
          <div className="pointer-events-none absolute top-0 right-0 bottom-0 hidden w-[58%] lg:block">
            <img
              src="images/composing-stick.jpg"
              alt="A brass composing stick holding a line of metal foundry type on ivory rag paper"
              className="h-full w-full object-cover object-[60%_50%] opacity-95"
              style={{
                maskImage: "linear-gradient(to right, transparent 0%, #000 34%, #000 100%)",
                WebkitMaskImage: "linear-gradient(to right, transparent 0%, #000 34%, #000 100%)",
              }}
              onError={(e) => (e.currentTarget.parentElement?.remove(), undefined)}
            />
          </div>

          <div className="relative py-10 lg:py-16">
            <h1 className="disp text-[clamp(72px,15vw,220px)] leading-[0.82] tracking-[-0.03em]">
              Type<span className="text-[#c8341e]">case</span>
            </h1>
            <p className="mt-6 max-w-[42ch] text-[19px] leading-[1.45] lg:max-w-[34ch]">
              A working specimen room for the Google Fonts library. Browse {CATALOG.length} faces, set your own
              copy in them, then pull the family and set it on the machine.
            </p>
            <p className="lab mt-5 max-w-[52ch] text-[#8a8072] lg:max-w-[38ch]">
              Below: the tool, live. Then the dossier — whether this already exists, how heavy it is, and what to
              build it in so it stays light.
            </p>
            <div className="mt-8 flex flex-wrap gap-2">
              <a
                href="#specimen"
                className="lab border border-[#14110e] px-4 py-2.5 transition-colors duration-150 hover:bg-[#14110e] hover:text-[#f2ede4]"
              >
                Open the specimen room ↓
              </a>
              <a
                href="#dossier"
                className="lab border border-[#c8341e] bg-[#c8341e] px-4 py-2.5 text-[#f2ede4] transition-colors duration-150 hover:border-[#14110e] hover:bg-[#14110e]"
              >
                Go straight to the answer
              </a>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-baseline justify-between gap-4 border-y border-[#14110e] py-2">
          <span className="lab text-[#8a8072]">
            Fig. 1 — composing stick, 12 pt foundry sort, brass. Fig. 2 below — the type case
          </span>
          <span className="lab num text-[#8a8072]">Ed. 01 · {CATALOG.length} families indexed</span>
        </div>
      </header>

      {/* ——— the tool ——— */}
      <main
        id="specimen"
        className="mx-auto grid max-w-[1400px] grid-cols-1 gap-x-10 px-5 lg:grid-cols-[320px_minmax(0,1fr)] lg:px-10"
      >
        <aside
          id="index"
          className="order-2 min-h-0 border-t border-[#14110e] pt-4 lg:order-1 lg:sticky lg:top-0 lg:h-screen lg:border-t-0 lg:border-r lg:border-[#d8d0c2] lg:pr-6"
        >
          <Rail
            faces={faces}
            total={CATALOG.length}
            selected={selected}
            onSelect={setSelected}
            query={query}
            setQuery={setQuery}
            cat={cat}
            setCat={setCat}
          />
        </aside>

        <div className="order-1 min-w-0 lg:order-2">
          <Sheet
            face={selected}
            preset={preset}
            onPreset={setPresetId}
            onPair={(name) => {
              const f = CATALOG.find((x) => x.n === name);
              if (f) {
                setSelected(f);
                document.getElementById("specimen")?.scrollIntoView({ block: "start" });
              }
            }}
          />
        </div>
      </main>

      {/* ——— the type case, plate two ——— */}
      <div className="mx-auto mt-20 max-w-[1400px] px-5 lg:px-10">
        <div className="relative h-[220px] overflow-hidden border-y border-[#14110e] md:h-[300px]">
          <img
            src="images/type-case.jpg"
            alt="An old wooden type case drawer, its compartments holding worn wooden and lead sorts"
            className="h-full w-full object-cover"
            onError={(e) => (e.currentTarget.parentElement?.remove(), undefined)}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#f2ede4] via-[#f2ede4]/10 to-transparent" />
          <p className="lab absolute bottom-3 left-4 max-w-[34ch] text-[#14110e]">
            Fig. 2 — a California job case. Every face in this index was once a drawer like this one.
          </p>
        </div>
      </div>

      <Dossier />

      {/* ——— colophon ——— */}
      <footer className="mt-24 border-t border-[#14110e]">
        <div className="mx-auto grid max-w-[1400px] gap-6 px-5 py-10 md:grid-cols-3 lg:px-10">
          <p className="lab text-[#8a8072]">
            Colophon — set in Bodoni Moda, IBM Plex Sans and IBM Plex Mono. Specimens set in the families
            themselves, fetched live from the Google Fonts CSS2 API.
          </p>
          <p className="lab text-[#8a8072]">
            Every family indexed here is released under the SIL Open Font Licence 1.1: free to use, embed and
            modify, including in commercial work, provided the licence travels with the files.
          </p>
          <p className="lab text-[#c8341e]">
            Typecase · a specimen room and retrieval utility · Windows 10 (1809+) and Windows 11 · no account, no
            telemetry, no tray agent
          </p>
        </div>
      </footer>
    </div>
  );
}
